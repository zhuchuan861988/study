let currentConfig = null;
let currentFiles = [];
let editingFileIndex = null;

// DOM 元素
const basePathInput = document.getElementById('base-path');
const reposConfigTextarea = document.getElementById('repos-config');
const pathMappingTextarea = document.getElementById('path-mapping');
const ftpTypeSelect = document.getElementById('ftp-type');
const ftpHostInput = document.getElementById('ftp-host');
const ftpPortInput = document.getElementById('ftp-port');
const ftpUserInput = document.getElementById('ftp-user');
const ftpPasswordInput = document.getElementById('ftp-password');
const fileListDiv = document.getElementById('file-list');
const fileCountSpan = document.getElementById('file-count');
const uploadBtn = document.getElementById('upload-btn');
const scanWithCommitBtn = document.getElementById('scan-with-commit-btn');
const saveConfigBtn = document.getElementById('save-config-btn');
const loadConfigBtn = document.getElementById('load-config-btn');
const cloneAllBtn = document.getElementById('clone-all-btn');
const refreshFilesBtn = document.getElementById('refresh-files-btn');
const clearLogBtn = document.getElementById('clear-log-btn');
const selectAllBtn = document.getElementById('select-all-btn');
const deselectAllBtn = document.getElementById('deselect-all-btn');
const removeSelectedBtn = document.getElementById('remove-selected-btn');
const addFileBtn = document.getElementById('add-file-btn');
const selectRepo = document.getElementById('select-repo');
const customFilePath = document.getElementById('custom-file-path');
const logArea = document.getElementById('log-area');
const progressBar = document.getElementById('progress-bar');
const progressFill = document.getElementById('progress-fill');
const repoListDiv = document.getElementById('repo-list');
const editModeBtn = document.getElementById('edit-mode-btn');
const fileEditor = document.getElementById('file-editor');
const editingFilePath = document.getElementById('editing-file-path');
const fileContentInput = document.getElementById('file-content-input');
const saveFileContentBtn = document.getElementById('save-file-content-btn');
const cancelEditBtn = document.getElementById('cancel-edit-btn');
const treeView = document.getElementById('tree-view');
const treeContent = document.getElementById('tree-content');

let currentRepoStructure = {};

// 添加日志
function addLog(message, type = 'info') {
  const logEntry = document.createElement('div');
  logEntry.className = `log-entry log-${type}`;
  logEntry.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
  logArea.appendChild(logEntry);
  logEntry.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// 清空日志
clearLogBtn.addEventListener('click', () => {
  logArea.innerHTML = '<div class="log-entry log-info">日志已清空</div>';
});

// 保存配置
saveConfigBtn.addEventListener('click', async () => {
  try {
    const repos = JSON.parse(reposConfigTextarea.value);
    const pathMapping = JSON.parse(pathMappingTextarea.value);
    currentConfig = {
      basePath: basePathInput.value,
      repos: repos,
      pathMapping: pathMapping,
      ftp: {
        type: ftpTypeSelect.value,
        host: ftpHostInput.value,
        port: parseInt(ftpPortInput.value) || (ftpTypeSelect.value === 'sftp' ? 22 : 21),
        user: ftpUserInput.value,
        password: ftpPasswordInput.value
      }
    };
    await window.electronAPI.saveConfig(currentConfig);
    addLog('配置保存成功', 'success');
    renderRepoList();
    updateRepoSelect();
  } catch (error) {
    addLog(`配置保存失败：${error.message}`, 'error');
  }
});

// 加载配置
loadConfigBtn.addEventListener('click', async () => {
  const config = await window.electronAPI.loadConfig();
  if (config && Object.keys(config).length > 0) {
    currentConfig = config;
    basePathInput.value = config.basePath || '';
    ftpTypeSelect.value = config.ftp?.type || 'sftp';
    ftpHostInput.value = config.ftp?.host || '';
    ftpPortInput.value = config.ftp?.port || (config.ftp?.type === 'sftp' ? 22 : 21);
    ftpUserInput.value = config.ftp?.user || '';
    ftpPasswordInput.value = config.ftp?.password || '';
    if (config.repos) {
      reposConfigTextarea.value = JSON.stringify(config.repos, null, 2);
    }
    if (config.pathMapping) {
      pathMappingTextarea.value = JSON.stringify(config.pathMapping, null, 2);
    }
    addLog('配置加载成功', 'success');
    renderRepoList();
    updateRepoSelect();
  } else {
    addLog('暂无保存的配置', 'info');
  }
});

// 渲染仓库列表
function renderRepoList() {
  if (!currentConfig || !currentConfig.repos) {
    repoListDiv.innerHTML = '<div style="text-align: center; padding: 20px; color: #999; grid-column: 1/-1;">请先保存配置</div>';
    return;
  }
  
  const repos = currentConfig.repos;
  const basePath = currentConfig.basePath || '';
  
  let html = '';
  for (const [repoName, repoUrl] of Object.entries(repos)) {
    const localPath = `${basePath}/${repoName}`;
    html += `
      <div class="repo-card" data-repo="${repoName}">
        <div class="repo-name">📁 ${repoName}</div>
        <div class="repo-status" id="status-${repoName.replace(/\./g, '-')}">状态：待检测</div>
        <input type="text" class="repo-commit-input" id="commit-${repoName.replace(/\./g, '-')}" placeholder="输入Commit ID（多个用逗号分隔）">
      </div>
    `;
  }
  repoListDiv.innerHTML = html;
}

// 更新仓库选择下拉框
function updateRepoSelect() {
  if (!currentConfig || !currentConfig.repos) return;
  
  selectRepo.innerHTML = '<option value="">选择语言仓库</option>';
  for (const repoName of Object.keys(currentConfig.repos)) {
    const option = document.createElement('option');
    option.value = repoName;
    option.textContent = repoName;
    selectRepo.appendChild(option);
  }
}

// 加载目录树
async function loadRepoTree(repoName) {
  if (!currentConfig || !currentConfig.basePath) return;
  
  const repoPath = `${currentConfig.basePath}/${repoName}`;
  treeContent.innerHTML = '<div>加载中...</div>';
  treeView.style.display = 'block';
  
  const result = await window.electronAPI.getRepoStructure(repoPath, '');
  
  if (result.success) {
    currentRepoStructure[repoName] = result.items;
    renderTree(result.items, '');
  } else {
    treeContent.innerHTML = `<div>加载失败：${result.error}</div>`;
  }
}

// 渲染目录树
function renderTree(items, parentPath) {
  if (!items || items.length === 0) {
    treeContent.innerHTML = '<div>目录为空</div>';
    return;
  }
  
  let html = '';
  for (const item of items) {
    const fullPath = parentPath ? `${parentPath}/${item.name}` : item.name;
    if (item.type === 'directory') {
      html += `
        <div class="tree-item directory" data-path="${fullPath}" data-type="directory" data-name="${item.name}">
          📁 ${item.name}/
        </div>
        <div class="tree-children" id="children-${fullPath.replace(/[\/\.]/g, '-')}" style="display: none;"></div>
      `;
    } else {
      html += `
        <div class="tree-item file" data-path="${fullPath}" data-type="file" data-name="${item.name}">
          📄 ${item.name}
        </div>
      `;
    }
  }
  treeContent.innerHTML = html;
  
  // 添加点击事件
  document.querySelectorAll('.tree-item.directory').forEach(el => {
    el.addEventListener('click', async (e) => {
      e.stopPropagation();
      const path = el.dataset.path;
      const childrenDiv = document.getElementById(`children-${path.replace(/[\/\.]/g, '-')}`);
      
      if (childrenDiv.style.display === 'none') {
        // 加载子目录
        const repoName = selectRepo.value;
        const repoPath = `${currentConfig.basePath}/${repoName}`;
        const result = await window.electronAPI.getRepoStructure(repoPath, path);
        if (result.success && result.items.length > 0) {
          renderChildrenTree(result.items, path, childrenDiv);
        }
        childrenDiv.style.display = 'block';
        el.style.fontWeight = 'bold';
      } else {
        childrenDiv.style.display = 'none';
        el.style.fontWeight = 'normal';
      }
    });
  });
  
  document.querySelectorAll('.tree-item.file').forEach(el => {
    el.addEventListener('click', () => {
      const path = el.dataset.path;
      customFilePath.value = path;
      addLog(`已选择文件：${path}`, 'info');
    });
  });
}

// 渲染子目录树
function renderChildrenTree(items, parentPath, container) {
  let html = '';
  for (const item of items) {
    const fullPath = parentPath ? `${parentPath}/${item.name}` : item.name;
    if (item.type === 'directory') {
      html += `
        <div class="tree-item directory" data-path="${fullPath}" data-type="directory">
          📁 ${item.name}/
        </div>
        <div class="tree-children" id="children-${fullPath.replace(/[\/\.]/g, '-')}" style="display: none;"></div>
      `;
    } else {
      html += `
        <div class="tree-item file" data-path="${fullPath}" data-type="file">
          📄 ${item.name}
        </div>
      `;
    }
  }
  container.innerHTML = html;
  
  // 重新绑定事件
  container.querySelectorAll('.tree-item.directory').forEach(el => {
    el.addEventListener('click', async (e) => {
      e.stopPropagation();
      const path = el.dataset.path;
      const childrenDiv = document.getElementById(`children-${path.replace(/[\/\.]/g, '-')}`);
      
      if (childrenDiv && childrenDiv.style.display === 'none') {
        const repoName = selectRepo.value;
        const repoPath = `${currentConfig.basePath}/${repoName}`;
        const result = await window.electronAPI.getRepoStructure(repoPath, path);
        if (result.success && result.items.length > 0) {
          renderChildrenTree(result.items, path, childrenDiv);
        }
        childrenDiv.style.display = 'block';
      } else if (childrenDiv) {
        childrenDiv.style.display = 'none';
      }
    });
  });
  
  container.querySelectorAll('.tree-item.file').forEach(el => {
    el.addEventListener('click', () => {
      customFilePath.value = el.dataset.path;
      addLog(`已选择文件：${el.dataset.path}`, 'info');
    });
  });
}

// 仓库选择变化时加载目录树
selectRepo.addEventListener('change', async () => {
  const repoName = selectRepo.value;
  if (repoName && currentConfig && currentConfig.basePath) {
    await loadRepoTree(repoName);
  } else {
    treeView.style.display = 'none';
  }
});

// 克隆/更新所有仓库
cloneAllBtn.addEventListener('click', async () => {
  if (!currentConfig || !currentConfig.repos) {
    addLog('请先保存配置', 'error');
    return;
  }
  
  const basePath = currentConfig.basePath;
  if (!basePath) {
    addLog('请设置基础存放路径', 'error');
    return;
  }
  
  const repos = currentConfig.repos;
  addLog(`开始处理 ${Object.keys(repos).length} 个仓库...`, 'info');
  
  for (const [repoName, repoUrl] of Object.entries(repos)) {
    const targetPath = `${basePath}/${repoName}`;
    addLog(`正在处理: ${repoName}...`, 'info');
    const result = await window.electronAPI.cloneOrPullRepo(repoUrl, targetPath);
    if (result.success) {
      addLog(`✅ ${repoName}: ${result.message}`, 'success');
      const statusElem = document.getElementById(`status-${repoName.replace(/\./g, '-')}`);
      if (statusElem) statusElem.innerHTML = '状态：✅ 已就绪';
    } else {
      addLog(`❌ ${repoName}: ${result.error}`, 'error');
      const statusElem = document.getElementById(`status-${repoName.replace(/\./g, '-')}`);
      if (statusElem) statusElem.innerHTML = '状态：❌ 失败';
    }
  }
  addLog('所有仓库处理完成', 'success');
});

// 获取所有仓库的Commit IDs
function getCommitIdsMap() {
  const commitIdsMap = {};
  if (!currentConfig || !currentConfig.repos) return commitIdsMap;
  
  for (const repoName of Object.keys(currentConfig.repos)) {
    const inputId = `commit-${repoName.replace(/\./g, '-')}`;
    const input = document.getElementById(inputId);
    if (input && input.value.trim()) {
      commitIdsMap[repoName] = input.value.trim();
    }
  }
  return commitIdsMap;
}

// 扫描有Commit ID的仓库
scanWithCommitBtn.addEventListener('click', async () => {
  if (!currentConfig || !currentConfig.repos) {
    addLog('请先保存配置', 'error');
    return;
  }
  
  const basePath = currentConfig.basePath;
  if (!basePath) {
    addLog('请设置基础存放路径', 'error');
    return;
  }
  
  const commitIdsMap = getCommitIdsMap();
  const hasCommit = Object.values(commitIdsMap).some(v => v && v.trim());
  
  if (!hasCommit) {
    addLog('请至少填写一个仓库的Commit ID', 'error');
    return;
  }
  
  // 🔧 构建仓库路径映射 - 这里把 repoName 映射到完整路径
  const repos = {};
  for (const [repoName] of Object.entries(currentConfig.repos)) {
    repos[repoName] = `${basePath}/${repoName}`;
  }
  
  const pathMapping = currentConfig.pathMapping || {};
  
  addLog(`开始扫描有Commit ID的仓库...`, 'info');
  
  // 🔧 参数顺序：repos, commitIdsMap, pathMapping
  const result = await window.electronAPI.scanReposByCommits(repos, commitIdsMap, pathMapping);
  
  if (result.success) {
    currentFiles = result.files;
    displayFiles(currentFiles);
    
    let totalFiles = result.files.length;
    let filteredInfo = '';
    result.repoStatus.forEach(s => {
      if (s.filteredCount > 0) {
        filteredInfo += ` ${s.repoName}过滤了${s.filteredCount}个Dev文件；`;
      }
    });
    
    addLog(`扫描完成，共发现 ${totalFiles} 个修改文件${filteredInfo ? '（' + filteredInfo + '）' : ''}`, 'success');
    
    // 更新仓库状态
    for (const status of result.repoStatus) {
      const statusElem = document.getElementById(`status-${status.repoName.replace(/\./g, '-')}`);
      if (statusElem) {
        if (status.skipped) {
          statusElem.innerHTML = `状态：⏭️ ${status.message}`;
        } else if (status.error) {
          statusElem.innerHTML = `状态：❌ ${status.error}`;
        } else {
          statusElem.innerHTML = `状态：✅ ${status.branch} | ${status.commit} | ${status.fileCount}个文件修改 | 过滤Dev:${status.filteredCount}个 | Commit: ${status.commitIds}`;
        }
      }
    }
  } else {
    addLog(`扫描失败：${result.error}`, 'error');
  }
});

// 手动添加文件
addFileBtn.addEventListener('click', async () => {
  const repoName = selectRepo.value;
  const filePath = customFilePath.value.trim();
  
  if (!repoName) {
    addLog('请选择语言仓库', 'error');
    return;
  }
  
  if (!filePath) {
    addLog('请输入文件路径', 'error');
    return;
  }
  
  const basePath = currentConfig.basePath;
  if (!basePath) {
    addLog('请先保存配置（基础存放路径）', 'error');
    return;
  }
  
  const pathMapping = currentConfig.pathMapping || {};
  
  const result = await window.electronAPI.addCustomFile(basePath, repoName, filePath, pathMapping);
  
  if (result.success) {
    const exists = currentFiles.some(f => f.repoName === repoName && f.path === filePath);
    if (!exists) {
      currentFiles.push(result.file);
      addLog(`✅ 已添加文件: ${repoName}/${filePath}`, 'success');
    } else {
      addLog(`文件已存在，无需重复添加: ${repoName}/${filePath}`, 'info');
    }
    displayFiles(currentFiles);
    customFilePath.value = '';
  } else {
    addLog(`添加失败：${result.error}`, 'error');
  }
});

// 显示文件列表
function displayFiles(files) {
  if (!files || files.length === 0) {
    fileListDiv.innerHTML = '<div style="text-align: center; padding: 20px; color: #999;">暂无文件，请扫描仓库或手动添加</div>';
    fileCountSpan.textContent = '0个文件';
    uploadBtn.disabled = true;
    return;
  }
  
  fileListDiv.innerHTML = '';
  files.forEach((file, index) => {
    const fileItem = document.createElement('div');
    fileItem.className = 'file-item';
    fileItem.innerHTML = `
      <input type="checkbox" class="file-checkbox" data-index="${index}" checked>
      <span class="file-repo ${file.isCustom ? 'file-custom' : ''}">${file.repoName}${file.isCustom ? ' (手动)' : ''}</span>
      <span class="file-path" title="本地: ${file.fullPath}\n远程: ${file.remotePath}">📄 ${file.path}</span>
    `;
    fileListDiv.appendChild(fileItem);
  });
  
  fileCountSpan.textContent = `${files.length}个文件`;
  uploadBtn.disabled = false;
}

// 获取选中的文件
function getSelectedFiles() {
  const checkboxes = document.querySelectorAll('.file-checkbox:checked');
  const selectedIndices = Array.from(checkboxes).map(cb => parseInt(cb.dataset.index));
  return currentFiles.filter((_, index) => selectedIndices.includes(index));
}

// 全选
selectAllBtn.addEventListener('click', () => {
  const checkboxes = document.querySelectorAll('.file-checkbox');
  checkboxes.forEach(cb => cb.checked = true);
});

// 取消全选
deselectAllBtn.addEventListener('click', () => {
  const checkboxes = document.querySelectorAll('.file-checkbox');
  checkboxes.forEach(cb => cb.checked = false);
});

// 移除选中文件
removeSelectedBtn.addEventListener('click', () => {
  const selected = getSelectedFiles();
  if (selected.length === 0) {
    addLog('请先选中要移除的文件', 'error');
    return;
  }
  
  currentFiles = currentFiles.filter(f => !selected.includes(f));
  displayFiles(currentFiles);
  addLog(`已移除 ${selected.length} 个文件`, 'info');
});

// 刷新文件列表
refreshFilesBtn.addEventListener('click', () => {
  if (currentFiles.length > 0) {
    displayFiles(currentFiles);
    addLog('文件列表已刷新', 'info');
  }
});

// 编辑模式 - 编辑选中文件
editModeBtn.addEventListener('click', async () => {
  const selected = getSelectedFiles();
  if (selected.length === 0) {
    addLog('请先选中要编辑的文件', 'error');
    return;
  }
  
  if (selected.length > 1) {
    addLog('一次只能编辑一个文件，请只选中一个文件', 'error');
    return;
  }
  
  const file = selected[0];
  editingFileIndex = currentFiles.findIndex(f => f === file);
  
  editingFilePath.textContent = `${file.repoName}/${file.path}`;
  
  // 读取文件内容
  try {
    const fs = require('fs').promises;
    const content = await fs.readFile(file.fullPath, 'utf-8');
    fileContentInput.value = content;
    fileEditor.style.display = 'block';
    addLog(`开始编辑: ${file.repoName}/${file.path}`, 'info');
  } catch (error) {
    addLog(`读取文件失败：${error.message}`, 'error');
  }
});

// 保存文件内容
saveFileContentBtn.addEventListener('click', async () => {
  if (editingFileIndex === null) return;
  
  const file = currentFiles[editingFileIndex];
  const newContent = fileContentInput.value;
  
  try {
    const fs = require('fs').promises;
    await fs.writeFile(file.fullPath, newContent, 'utf-8');
    addLog(`✅ 已保存: ${file.repoName}/${file.path}`, 'success');
    fileEditor.style.display = 'none';
    editingFileIndex = null;
    fileContentInput.value = '';
  } catch (error) {
    addLog(`保存文件失败：${error.message}`, 'error');
  }
});

// 取消编辑
cancelEditBtn.addEventListener('click', () => {
  fileEditor.style.display = 'none';
  editingFileIndex = null;
  fileContentInput.value = '';
  addLog('已取消编辑', 'info');
});

// 上传进度监听
window.electronAPI.onUploadProgress((data) => {
  progressFill.style.width = `${data.percent}%`;
});

// 上传文件
uploadBtn.addEventListener('click', async () => {
  if (!currentConfig || !currentConfig.ftp.host) {
    addLog('请先配置FTP/SFTP信息', 'error');
    return;
  }
  
  const selectedFiles = getSelectedFiles();
  if (selectedFiles.length === 0) {
    addLog('请至少选择一个文件', 'error');
    return;
  }
  
  progressBar.style.display = 'block';
  progressFill.style.width = '0%';
  
  const protocol = currentConfig.ftp.type === 'sftp' ? 'SFTP' : 'FTP';
  addLog(`开始上传 ${selectedFiles.length} 个文件到 ${protocol}服务器 ${currentConfig.ftp.host}...`, 'info');
  
  const result = await window.electronAPI.uploadToServer(currentConfig.ftp, selectedFiles);
  
  if (result.success) {
    let successCount = 0;
    let failCount = 0;
    result.results.forEach(r => {
      if (r.success) {
        successCount++;
        addLog(`✅ ${r.file} -> ${r.remotePath} - 上传成功`, 'success');
      } else {
        failCount++;
        addLog(`❌ ${r.file} - 上传失败：${r.message}`, 'error');
      }
    });
    addLog(`上传完成：成功 ${successCount} 个，失败 ${failCount} 个`, successCount > 0 ? 'success' : 'error');
  } else {
    addLog(`上传失败：${result.error}`, 'error');
  }
  
  setTimeout(() => {
    progressBar.style.display = 'none';
    progressFill.style.width = '0%';
  }, 1000);
});

// FTP类型切换时更新默认端口
ftpTypeSelect.addEventListener('change', () => {
  if (ftpTypeSelect.value === 'sftp') {
    if (ftpPortInput.value === '21') ftpPortInput.value = '22';
  } else {
    if (ftpPortInput.value === '22') ftpPortInput.value = '21';
  }
});

// 页面加载时加载配置
loadConfigBtn.click();